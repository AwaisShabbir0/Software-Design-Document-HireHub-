#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

class UserAuthentication {
public:
    void login(User& user) {
        cout << user.name << " logged in." << endl;
    }
    void logout(User& user) {
        cout << user.name << " logged out." << endl;
    }
    void signup(User& user) {
        cout << user.name << " signed up." << endl;
    }
};

class CV {
private:
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;

public:
    CV(int cvID, int userID, string filePath, string reviewStatus)
        : cvID(cvID), userID(userID), filePath(filePath), reviewStatus(reviewStatus) {}

    string getFilePath() {
        return filePath;
    }
};

class CVManager {
public:
    void upload(CV& cv, string userName) {
        cout << "CV uploaded by " << userName << endl;
    }

    void review(CV& cv, string userName) {
        cout << userName << " is reviewing their CV." << endl;
    }
};

class Job {
private:
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;

public:
    Job(int jobID, string title, string description, string requirements, float salary, int categoryID)
        : jobID(jobID), title(title), description(description), requirements(requirements),
          salary(salary), categoryID(categoryID) {}

    int getJobID() { return jobID; }
    string getTitle() { return title; }

    void apply() {
        cout << "Job application for: " << title << endl;
    }
};

class JobApplication {
private:
    int applicationID;
    int jobID;
    int userID;
    string status;
    time_t dateApplied;

public:
    JobApplication(int userID, int jobID)
        : userID(userID), jobID(jobID), status("Applied"), dateApplied(time(0)) {
        applicationID = rand() % 1000;
    }

    void updateStatus(string newStatus) {
        status = newStatus;
        cout << "Application status updated to: " << status << endl;
    }
};

class JobSeeker : public User {
private:
    CVManager cvManager;

public:
    void applyForJob(Job& job) {
        JobApplication application(userId, job.getJobID());
        cout << name << " applied for job: " << job.getTitle() << endl;
    }

    void findJob() {
        cout << name << " is looking for a job." << endl;
    }

    void uploadCV(CV& cv) {
        cvManager.upload(cv, name);
    }

    void reviewCV(CV& cv) {
        cvManager.review(cv, name);
    }
};

class Admin : public User {
public:
    void manageUsers() {
        cout << "Admin : " << name << " managing users." << endl;
    }

    void manageJobs() {
        cout << "Admin : " << name << " managing jobs." << endl;
    }

    void generateReports() {
        cout << "Admin : " << name << " generating reports." << endl;
    }
};

class Freelancer : public User {
public:
    void applyForFreelanceJob(Job& job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }

    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

class Employer : public User {
public:
    void postJob(Job& job) {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }

    void editJob(Job& job) {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }

    void deleteJob(Job& job) {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }

    void hireFreelancer(Freelancer& freelancer) {
        cout << "Employer hired freelancer: " << freelancer.name << endl;
    }
};

int main() {
    UserAuthentication auth;

    cout << "\n=== Job Seeker Operations ===" << endl;
    JobSeeker jobSeeker;
    jobSeeker.name = "Awais Shabbir";
    jobSeeker.userId = 101;
    auth.signup(jobSeeker);
    auth.login(jobSeeker);
    CV cv(1, jobSeeker.userId, "cv_path.pdf", "Pending");
    jobSeeker.uploadCV(cv);
    jobSeeker.findJob();
    Job job1(1, "Software Engineer", "Build systems", "C++, Git", 80000, 10);
    jobSeeker.applyForJob(job1);
    jobSeeker.reviewCV(cv);
    auth.logout(jobSeeker);

    cout << "\n=== Admin Operations ===" << endl;
    Admin admin;
    admin.name = "Owais Awan";
    auth.signup(admin);
    auth.login(admin);
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    auth.logout(admin);

    cout << "\n=== Employer Operations ===" << endl;
    Employer employer;
    employer.name = "Company Inc.";
    auth.signup(employer);
    auth.login(employer);
    Job job2(2, "Software Developer", "Develop software", "Java, Spring", 75000, 12);
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    auth.logout(employer);

    cout << "\n=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.name = "Freelance Expert";
    auth.signup(freelancer);
    auth.login(freelancer);
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    auth.logout(freelancer);

    return 0;
}


// before Applying

// #include <iostream>
// #include <string>
// using namespace std;

// class CV {
// public:
//     string filePath;
// };

// class Job {
//     int jobID;
//     string title;
// public:
//     Job(int id, string t) : jobID(id), title(t) {}
//     string getTitle() { return title; }
// };

// class User {
// public:
//     string name, email;
// };

// class JobSeeker : public User {
// public:
//     void login() {
//         cout << name << " logged in." << endl;
//     }
//     void logout() {
//         cout << name << " logged out." << endl;
//     }
//     void signup() {
//         cout << name << " signed up." << endl;
//     }
//     void uploadCV(CV& cv) {
//         cout << "CV uploaded by " << name << endl;
//     }
//     void reviewCV(CV& cv) {
//         cout << name << " is reviewing their CV." << endl;
//     }
//     void applyForJob(Job& job) {
//         cout << name << " applied for job: " << job.getTitle() << endl;
//     }
// };

// int main() {
//     JobSeeker js;
//     js.name = "Awais";

//     CV cv;
//     Job job(1, "Software Engineer");

//     js.signup();
//     js.login();
//     js.uploadCV(cv);
//     js.reviewCV(cv);
//     js.applyForJob(job);
//     js.logout();

//     return 0;
// }

//// after Applying

// #include <iostream>
// #include <string>
// using namespace std;

// class CV {
// public:
//     string filePath;
// };

// class Job {
//     int jobID;
//     string title;
// public:
//     Job(int id, string t) : jobID(id), title(t) {}
//     string getTitle() { return title; }
// };

// class User {
// public:
//     string name, email;
// };

// class UserAuthentication {
// public:
//     void login(User& user) {
//         cout << user.name << " logged in." << endl;
//     }
//     void logout(User& user) {
//         cout << user.name << " logged out." << endl;
//     }
//     void signup(User& user) {
//         cout << user.name << " signed up." << endl;
//     }
// };

// class CVManager {
// public:
//     void upload(CV& cv, const string& name) {
//         cout << "CV uploaded by " << name << endl;
//     }
//     void review(CV& cv, const string& name) {
//         cout << name << " is reviewing their CV." << endl;
//     }
// };

// class JobSeeker : public User {
// private:
//     CVManager cvManager;
// public:
//     void applyForJob(Job& job) {
//         cout << name << " applied for job: " << job.getTitle() << endl;
//     }
//     void uploadCV(CV& cv) {
//         cvManager.upload(cv, name);
//     }
//     void reviewCV(CV& cv) {
//         cvManager.review(cv, name);
//     }
// };

// int main() {
//     JobSeeker js;
//     js.name = "Awais";

//     UserAuthentication auth;
//     CV cv;
//     Job job(1, "Software Engineer");

//     auth.signup(js);
//     auth.login(js);
//     js.uploadCV(cv);
//     js.reviewCV(cv);
//     js.applyForJob(job);
//     auth.logout(js);

//     return 0;
// }
