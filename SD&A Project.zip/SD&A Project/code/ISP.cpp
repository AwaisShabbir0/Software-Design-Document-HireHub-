#include <iostream>
#include <string>
using namespace std;

// ================= USER BASE =================
class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

// ================= INTERFACES (ISP) =================
class Job;
class CV;
class Freelancer;

class JobSeekerActions {
public:
    virtual void applyForJob(Job& job) = 0;
    virtual void findJob() = 0;
    virtual void uploadCV(CV& cv) = 0;
    virtual void reviewCV(CV& cv) = 0;
};

class EmployerActions {
public:
    virtual void postJob(Job& job) = 0;
    virtual void editJob(Job& job) = 0;
    virtual void deleteJob(Job& job) = 0;
    virtual void hireFreelancer(Freelancer& freelancer) = 0;
};

class AdminActions {
public:
    virtual void manageUsers() = 0;
    virtual void manageJobs() = 0;
    virtual void generateReports() = 0;
};

class FreelancerActions {
public:
    virtual void applyForFreelanceJob(Job& job) = 0;
    virtual void getHired() = 0;
};

// ================= JOB & CV =================
class Job {
private:
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;

public:
    Job(int jobID, string title, string description, string requirements, float salary, int categoryID)
        : jobID(jobID), title(title), description(description), requirements(requirements),
          salary(salary), categoryID(categoryID) {}

    int getJobID() { return jobID; }
    string getTitle() { return title; }
};

class CV {
private:
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;

public:
    CV() {}
    CV(int cvID, int userID, string filePath, string reviewStatus)
        : cvID(cvID), userID(userID), filePath(filePath), reviewStatus(reviewStatus) {}

    string getFilePath() { return filePath; }
    void setFilePath(const string& path) { filePath = path; }
};

class CVManager {
public:
    void upload(CV& cv, string name) {
        cout << "CV uploaded by " << name << endl;
    }

    void review(CV& cv, string name) {
        cout << name << " is reviewing their CV." << endl;
    }
};

// ================= ROLES =================
class JobSeeker : public User, public JobSeekerActions {
private:
    CVManager cvManager;

public:
    void applyForJob(Job& job) override {
        cout << name << " applied for job: " << job.getTitle() << endl;
    }
    void findJob() override {
        cout << name << " is looking for a job." << endl;
    }
    void uploadCV(CV& cv) override {
        cvManager.upload(cv, name);
    }
    void reviewCV(CV& cv) override {
        cvManager.review(cv, name);
    }
};

class Admin : public User, public AdminActions {
public:
    void manageUsers() override {
        cout << "Admin : " << name << " managing users." << endl;
    }
    void manageJobs() override {
        cout << "Admin : " << name << " managing jobs." << endl;
    }
    void generateReports() override {
        cout << "Admin : " << name << " generating reports." << endl;
    }
};

class Freelancer;

class Employer : public User, public EmployerActions {
public:
    void postJob(Job& job) override {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }
    void editJob(Job& job) override {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }
    void deleteJob(Job& job) override {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }
    void hireFreelancer(Freelancer& freelancer) override;
};

class Freelancer : public User, public FreelancerActions {
public:
    void applyForFreelanceJob(Job& job) override {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }
    void getHired() override {
        cout << name << " got hired for a freelance job." << endl;
    }
};

void Employer::hireFreelancer(Freelancer& freelancer) {
    cout << "Employer hired freelancer: " << freelancer.name << endl;
}

// ================= AUTH =================
class UserAuthentication {
public:
    void login(User& user) {
        cout << user.name << " logged in." << endl;
    }
    void logout(User& user) {
        cout << user.name << " logged out." << endl;
    }
    void signup(User& user) {
        cout << user.name << " signed up." << endl;
    }
};

// ================= MAIN =================
int main() {
    UserAuthentication auth;

    cout << "\n=== Job Seeker Operations ===" << endl;
    JobSeeker jobSeeker;
    jobSeeker.name = "Awais Shabbir";
    jobSeeker.userId = 101;
    auth.signup(jobSeeker);
    auth.login(jobSeeker);
    CV cv(1, jobSeeker.userId, "cv_path.pdf", "Pending");
    jobSeeker.uploadCV(cv);
    jobSeeker.findJob();
    Job job1(1, "Software Engineer", "Build systems", "C++, Git", 80000, 10);
    jobSeeker.applyForJob(job1);
    // jobSeeker.reviewCV(cv);
    auth.logout(jobSeeker);

    cout << "\n=== Admin Operations ===" << endl;
    Admin admin;
    admin.name = "Owais Awan";
    auth.signup(admin);
    auth.login(admin);
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    auth.logout(admin);

    cout << "\n=== Employer Operations ===" << endl;
    Employer employer;
    employer.name = "Company Inc.";
    auth.signup(employer);
    auth.login(employer);
    Job job2(2, "Software Developer", "Develop applications", "Java, Spring", 60000, 101);
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    auth.logout(employer);

    cout << "\n=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.name = "Freelance Expert";
    auth.signup(freelancer);
    auth.login(freelancer);
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    auth.logout(freelancer);

    return 0;
}

// ==================== Before Code ====================

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     int userId;
//     string name;
//     string email;
//     string password;

//     void applyForJob() {
//         cout << name << " applied for a job.\n";
//     }

//     void postJob() {
//         cout << name << " posted a job.\n";
//     }

//     void manageUsers() {
//         cout << name << " managing users.\n";
//     }

//     void generateReports() {
//         cout << name << " generating reports.\n";
//     }
// };

// int main() {
//     User jobSeeker;
//     jobSeeker.name = "Awais";
//     jobSeeker.applyForJob();       // ✅ Needed
//     jobSeeker.manageUsers();       // ❌ Not needed

//     User admin;
//     admin.name = "Owais";
//     admin.generateReports();       // ✅ Needed
//     admin.applyForJob();           // ❌ Not relevant for Admin
//     return 0;
// }

// ==================== After Code ====================

// #include <iostream>
// #include <string>
// using namespace std;

// class Job {
// public:
//     string title;
//     Job(string t) : title(t) {}
// };

// class CV {
// public:
//     string filePath;
//     CV(string path) : filePath(path) {}
// };

// // Base User class
// class User {
// public:
//     int userId;
//     string name;
//     string email;
//     string password;
// };

// // Role-Specific Interfaces
// class JobSeekerActions {
// public:
//     virtual void applyForJob(Job& job) = 0;
//     virtual void uploadCV(CV& cv) = 0;
// };

// class EmployerActions {
// public:
//     virtual void postJob(Job& job) = 0;
// };

// class AdminActions {
// public:
//     virtual void manageUsers() = 0;
//     virtual void generateReports() = 0;
// };

// // Role Implementations
// class JobSeeker : public User, public JobSeekerActions {
// public:
//     void applyForJob(Job& job) override {
//         cout << name << " applied for job: " << job.title << endl;
//     }
//     void uploadCV(CV& cv) override {
//         cout << name << " uploaded CV: " << cv.filePath << endl;
//     }
// };

// class Employer : public User, public EmployerActions {
// public:
//     void postJob(Job& job) override {
//         cout << name << " posted job: " << job.title << endl;
//     }
// };

// class Admin : public User, public AdminActions {
// public:
//     void manageUsers() override {
//         cout << name << " managing users.\n";
//     }
//     void generateReports() override {
//         cout << name << " generating reports.\n";
//     }
// };

// // Main Function
// int main() {
//     Job job("Web Developer");
//     CV cv("cv_path.pdf");

//     JobSeeker seeker;
//     seeker.name = "Awais";
//     seeker.applyForJob(job);
//     seeker.uploadCV(cv);

//     Employer employer;
//     employer.name = "Company Inc.";
//     employer.postJob(job);

//     Admin admin;
//     admin.name = "Owais";
//     admin.manageUsers();
//     admin.generateReports();

//     return 0;
// }
