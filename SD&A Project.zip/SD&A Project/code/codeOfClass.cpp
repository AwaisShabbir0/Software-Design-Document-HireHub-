#include <iostream>
#include <string>
#include <ctime>

using namespace std;

class Job; // Forward declaration

class User {
protected:
    int userId;
    string name;
    string email;
    string password;

public:
    virtual void login() {
        cout << name << " logged in." << endl;
    }

    virtual void logout() {
        cout << name << " logged out." << endl;
    }

    virtual void signup() {
        cout << name << " signed up." << endl;
    }

    void setName(string n) { name = n; }
    string getName() { return name; }
};

class CV {
private:
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;

public:
    void upload() {
        cout << "CV uploaded at: " << filePath << endl;
    }

    void review() {
        cout << "CV is under review." << endl;
    }
};

class Job {
private:
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;

public:
    Job(int jobID, string title, string description, string requirements, float salary, int categoryID)
        : jobID(jobID), title(title), description(description), requirements(requirements),
          salary(salary), categoryID(categoryID) {}

    int getJobID() { return jobID; }
    string getTitle() { return title; }

    void apply() {
        cout << "Job application for: " << title << endl;
    }
};

class JobApplication {
private:
    int applicationID;
    int jobID;
    int userID;
    string status;
    time_t dateApplied;

public:
    JobApplication(int userID, int jobID)
        : userID(userID), jobID(jobID), status("Applied"), dateApplied(time(0)) {
        applicationID = rand() % 1000;
    }

    void updateStatus(string newStatus) {
        status = newStatus;
        cout << "Application status updated to: " << status << endl;
    }
};

class JobSeeker : public User {
private:
    CV cv;

public:
    void uploadCV() {
        cout << "CV uploaded by " << name << endl;
    }

    void applyForJob(Job job) {
        JobApplication application(userId, job.getJobID());
        cout << name << " applied for job: " << job.getTitle() << endl;
    }

    void findJob() {
        cout << name << " is looking for a job." << endl;
    }

    void reviewCV() {
        cout << name << " is reviewing their CV." << endl;
    }
};

class Admin : public User {
private:
    int adminID;

public:
    void manageUsers() {
        cout << "Admin : Owais Awan managing users." << endl;
    }

    void manageJobs() {
        cout << "Admin : Owais Awan managing jobs." << endl;
    }

    void generateReports() {
        cout << "Admin : Owais Awan generating reports." << endl;
    }
};

class Freelancer : public User {
private:
    string portfolio;

public:
    void applyForFreelanceJob(Job job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }

    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

class Employer : public User {
public:
    void postJob(Job job) {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }

    void editJob(Job job) {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }

    void deleteJob(Job job) {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }

    void hireFreelancer(Freelancer freelancer) {
        cout << "Employer hired freelancer: " << freelancer.getName() << endl;
    }
};

int main() {
    // ===== Job Seeker Operations =====
    cout << "=== Job Seeker Operations ===" << endl;
    JobSeeker jobSeeker;
    jobSeeker.setName("Awais Shabbir");
    jobSeeker.signup();
    jobSeeker.login();
    jobSeeker.uploadCV();
    jobSeeker.findJob();
    Job job1(1, "Software Engineer", "Develop software applications", "C++, Python", 70000, 101);
    jobSeeker.applyForJob(job1);
    // jobSeeker.reviewCV();
    jobSeeker.logout();

    cout << "\n";

    // ===== Admin Operations =====
    cout << "=== Admin Operations ===" << endl;
    Admin admin;
    admin.setName("Owais Awan");
    admin.signup();
    admin.login();
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    admin.logout();

    cout << "\n";

    // ===== Employer Operations =====
    cout << "=== Employer Operations ===" << endl;
    Employer employer;
    employer.setName("Company Inc.");
    employer.signup();
    employer.login();
    Job job2(2, "Software Developer", "Develop applications", "Java, Spring", 60000, 102);
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    employer.logout();

    cout << "\n";

    // ===== Freelancer Operations =====
    cout << "=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.setName("Freelance Expert");
    freelancer.signup();
    freelancer.login();
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    freelancer.logout();

    cout << "\nAll operations completed successfully." << endl;

    return 0;
}
