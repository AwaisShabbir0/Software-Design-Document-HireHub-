#include <iostream>
#include <string>
#include <ctime>
using namespace std;

class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

// ========== OCP-Compliant Interfaces ==========
class IJobPostingService {
public:
    virtual void postJob(class Job& job) = 0;
    virtual void editJob(class Job& job) = 0;
    virtual void deleteJob(class Job& job) = 0;
};

class ICVManagementService {
public:
    virtual void uploadCV(class CV& cv, string userName) = 0;
    virtual void reviewCV(class CV& cv, string userName) = 0;
};

class IAuthenticationService {
public:
    virtual void login(User& user) = 0;
    virtual void logout(User& user) = 0;
    virtual void signup(User& user) = 0;
};

class UserAuthentication : public IAuthenticationService {
public:
    void login(User& user) override {
        cout << user.name << " logged in." << endl;
    }
    void logout(User& user) override {
        cout << user.name << " logged out." << endl;
    }
    void signup(User& user) override {
        cout << user.name << " signed up." << endl;
    }
};

// ========== CV ==========
class CV {
private:
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;

public:
    CV() {}
    CV(int cvID, int userID, string filePath, string reviewStatus)
        : cvID(cvID), userID(userID), filePath(filePath), reviewStatus(reviewStatus) {}

    string getFilePath() { return filePath; }
    void setFilePath(const string& path) { filePath = path; }
};

class CVManager : public ICVManagementService {
public:
    void uploadCV(CV& cv, string userName) override {
        cout << "CV uploaded by " << userName << endl;
    }

    void reviewCV(CV& cv, string userName) override {
        cout << userName << " is reviewing their CV." << endl;
    }
};

// ========== Job ==========
class Job {
private:
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;

public:
    Job(int jobID, string title, string description, string requirements, float salary, int categoryID)
        : jobID(jobID), title(title), description(description), requirements(requirements),
          salary(salary), categoryID(categoryID) {}

    int getJobID() { return jobID; }
    string getTitle() { return title; }
};

// ========== Job Application ==========
class JobApplication {
private:
    int applicationID;
    int jobID;
    int userID;
    string status;
    time_t dateApplied;

public:
    JobApplication(int userID, int jobID)
        : userID(userID), jobID(jobID), status("Applied"), dateApplied(time(0)) {
        applicationID = rand() % 1000;
    }

    void updateStatus(string newStatus) {
        status = newStatus;
        cout << "Application status updated to: " << status << endl;
    }
};

// ========== JobSeeker ==========
class JobSeeker : public User {
private:
    IJobPostingService* jobPostingService;
    ICVManagementService* cvManager;

public:
    JobSeeker(IJobPostingService* jps, ICVManagementService* cms)
        : jobPostingService(jps), cvManager(cms) {}

    void applyForJob(Job& job) {
        JobApplication application(userId, job.getJobID());
        cout << name << " applied for job: " << job.getTitle() << endl;
    }

    void findJob() {
        cout << name << " is looking for a job." << endl;
    }

    void uploadCV(CV& cv) {
        cvManager->uploadCV(cv, name);
    }

    void reviewCV(CV& cv) {
        cvManager->reviewCV(cv, name);
    }
};

// ========== Admin ==========
class Admin : public User, public IJobPostingService, public ICVManagementService {
public:
    void postJob(Job& job) override {
        cout << "Admin posted job: " << job.getTitle() << endl;
    }

    void editJob(Job& job) override {
        cout << "Admin edited job: " << job.getTitle() << endl;
    }

    void deleteJob(Job& job) override {
        cout << "Admin deleted job: " << job.getTitle() << endl;
    }

    void uploadCV(CV& cv, string userName) override {
        cout << "Admin uploaded CV for: " << userName << endl;
    }

    void reviewCV(CV& cv, string userName) override {
        cout << "Admin is reviewing CV of: " << userName << endl;
    }

    void manageJobs() {
        cout << name << " managing jobs." << endl;
    }

    void manageUsers() {
        cout << name << " managing users." << endl;
    }

    void generateReports() {
        cout << name << " generating reports." << endl;
    }
};

// ========== Employer ==========
class Employer : public User, public IJobPostingService {
public:
    void postJob(Job& job) override {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }

    void editJob(Job& job) override {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }

    void deleteJob(Job& job) override {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }

    void hireFreelancer(User& freelancer) {
        cout << "Employer hired freelancer: " << freelancer.name << endl;
    }
};

// ========== Freelancer ==========
class Freelancer : public User {
public:
    void applyForFreelanceJob(Job& job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }

    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

// ========== Main ==========
int main() {
    IAuthenticationService* auth = new UserAuthentication();
    CVManager cvManager;
    Employer employer;
    IJobPostingService* jobPostingService = &employer;

    cout << "\n=== Job Seeker Operations ===" << endl;
    JobSeeker jobSeeker(jobPostingService, &cvManager);
    jobSeeker.name = "Awais Shabbir";
    jobSeeker.userId = 101;
    auth->signup(jobSeeker);
    auth->login(jobSeeker);
    CV cv(1, jobSeeker.userId, "cv_path.pdf", "Pending");
    jobSeeker.uploadCV(cv);
    jobSeeker.findJob();
    Job job1(1, "Software Engineer", "Build systems", "C++, Git", 80000, 10);
    jobSeeker.applyForJob(job1);
    // jobSeeker.reviewCV(cv); 
    auth->logout(jobSeeker);

    cout << "\n=== Admin Operations ===" << endl;
    Admin admin;
    admin.name = "Admin: Owais Awan";
    auth->signup(admin);
    auth->login(admin);
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    auth->logout(admin);

    cout << "\n=== Employer Operations ===" << endl;
    employer.name = "Company Inc.";
    auth->signup(employer);
    auth->login(employer);
    Job job2(2, "Software Developer", "Develop applications", "Java, Spring", 60000, 101);
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    auth->logout(employer);

    cout << "\n=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.name = "Freelance Expert";
    auth->signup(freelancer);
    auth->login(freelancer);
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    auth->logout(freelancer);

    delete auth;
    return 0;
}

//before

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name;
//     string email;
// };

// class AuthSystem {
// public:
//     void login(User& user) {
//         cout << user.name << " logged in.\n";
//     }
//     void logout(User& user) {
//         cout << user.name << " logged out.\n";
//     }
//     void signup(User& user) {
//         cout << user.name << " signed up.\n";
//     }
// };

// class Job {
//     string title;
// public:
//     Job(string t) : title(t) {}
//     string getTitle() { return title; }
// };

// class JobSeeker : public User {
// public:
//     void uploadCV(string cv) {
//         cout << name << " uploaded CV: " << cv << endl;
//     }
//     void apply(Job& job) {
//         cout << name << " applied for: " << job.getTitle() << endl;
//     }
// };

// int main() {
//     User u;
//     u.name = "Awais";
//     AuthSystem auth;
//     auth.signup(u);
//     auth.login(u);

//     JobSeeker seeker;
//     seeker.name = "Awais";
//     seeker.uploadCV("cv.pdf");
//     Job job("Software Engineer");
//     seeker.apply(job);

//     auth.logout(u);
//     return 0;
// }

// After

// #include <iostream>
// #include <string>
// using namespace std;

// // Base User class
// class User {
// public:
//     string name;
// };

// // OCP Interfaces
// class IAuthenticationService {
// public:
//     virtual void login(User& user) = 0;
//     virtual void logout(User& user) = 0;
//     virtual void signup(User& user) = 0;
// };

// // Concrete Auth class using Interface
// class UserAuth : public IAuthenticationService {
// public:
//     void login(User& user) override {
//         cout << user.name << " logged in.\n";
//     }
//     void logout(User& user) override {
//         cout << user.name << " logged out.\n";
//     }
//     void signup(User& user) override {
//         cout << user.name << " signed up.\n";
//     }
// };

// // CV & Job classes
// class CV {
// public:
//     string path;
//     CV(string p) : path(p) {}
// };

// class Job {
//     string title;
// public:
//     Job(string t) : title(t) {}
//     string getTitle() { return title; }
// };

// // OCP interfaces for services
// class ICVService {
// public:
//     virtual void uploadCV(CV& cv, const string& userName) = 0;
// };

// class IJobService {
// public:
//     virtual void apply(Job& job, const string& userName) = 0;
// };

// // Implementing Services
// class CVManager : public ICVService {
// public:
//     void uploadCV(CV& cv, const string& userName) override {
//         cout << userName << " uploaded CV: " << cv.path << endl;
//     }
// };

// class JobApplication : public IJobService {
// public:
//     void apply(Job& job, const string& userName) override {
//         cout << userName << " applied for: " << job.getTitle() << endl;
//     }
// };

// // JobSeeker using interfaces (OCP!)
// class JobSeeker : public User {
//     ICVService* cvService;
//     IJobService* jobService;
// public:
//     JobSeeker(ICVService* cvs, IJobService* js) : cvService(cvs), jobService(js) {}
//     void upload(CV& cv) { cvService->uploadCV(cv, name); }
//     void apply(Job& job) { jobService->apply(job, name); }
// };

// int main() {
//     UserAuth auth;
//     CVManager cvManager;
//     JobApplication jobApp;

//     JobSeeker seeker(&cvManager, &jobApp);
//     seeker.name = "Awais";

//     auth.signup(seeker);
//     auth.login(seeker);

//     CV cv("cv_path.pdf");
//     seeker.upload(cv);

//     Job job("Software Engineer");
//     seeker.apply(job);

//     auth.logout(seeker);
//     return 0;
// }
