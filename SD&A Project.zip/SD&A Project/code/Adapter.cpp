#include <iostream>
#include <string>
using namespace std;

// ================= BEFORE: Old Authentication =================
class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

class UserAuthentication {
public:
    virtual void login(User& user) {
        cout << user.name << " logged in." << endl;
    }
    virtual void logout(User& user) {
        cout << user.name << " logged out." << endl;
    }
    virtual void signup(User& user) {
        cout << user.name << " signed up." << endl;
    }
};

// ================= NEW SYSTEM: Different Interface =================
class NewAuthSystem {
public:
    void registerUser(const string& name, const string& email) {
        cout << name << " is registered using the new system." << endl;
    }

    void loginUser(const string& name) {
        cout << name << " logged in using the new system." << endl;
    }
};

// ================= ADAPTER =================
class AuthenticationAdapter : public UserAuthentication {
private:
    NewAuthSystem* newAuth;

public:
    AuthenticationAdapter(NewAuthSystem* newAuthSystem) {
        newAuth = newAuthSystem;
    }

    void signup(User& user) override {
        newAuth->registerUser(user.name, user.email);
    }

    void login(User& user) override {
        newAuth->loginUser(user.name);
    }

    void logout(User& user) override {
        cout << user.name << " logged out using the new system." << endl;
    }
};

// ================= MAIN =================
int main() {
    cout << "\n=== Adapter Pattern: Authentication ===" << endl;

    User user;
    user.name = "Awais Shabbir";
    user.email = "awais@example.com";

    NewAuthSystem newSystem;
    UserAuthentication* adapter = new AuthenticationAdapter(&newSystem);

    adapter->signup(user);
    adapter->login(user);
    adapter->logout(user);

    delete adapter;
    return 0;
}

// before

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name;
//     string email;
// };

// class UserAuthentication {
// public:
//     void signup(User& user) {
//         cout << user.name << " signed up (old system)." << endl;
//     }
//     void login(User& user) {
//         cout << user.name << " logged in (old system)." << endl;
//     }
// };

// int main() {
//     User user = {"Awais", "awais@email.com"};
//     UserAuthentication auth;

//     auth.signup(user);
//     auth.login(user);

//     return 0;
// }

//After 

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name;
//     string email;
// };

// // 🆕 New system with different interface
// class NewAuthSystem {
// public:
//     void registerUser(string name, string email) {
//         cout << name << " registered (new system)." << endl;
//     }
//     void loginUser(string name) {
//         cout << name << " logged in (new system)." << endl;
//     }
// };

// // ✅ Adapter bridges the old interface to the new system
// class AuthAdapter {
//     NewAuthSystem* newSys;
// public:
//     AuthAdapter(NewAuthSystem* sys) : newSys(sys) {}

//     void signup(User& user) {
//         newSys->registerUser(user.name, user.email);
//     }
//     void login(User& user) {
//         newSys->loginUser(user.name);
//     }
// };

// int main() {
//     User user = {"Awais", "awais@email.com"};
//     NewAuthSystem newSys;
//     AuthAdapter adapter(&newSys);

//     adapter.signup(user);
//     adapter.login(user);

//     return 0;
// }
