#include <iostream>
#include <string>
using namespace std;

// ========== Bridge Pattern Interfaces & Classes ==========
class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

class AuthenticationSystem {
public:
    virtual void signup(User& user) = 0;
    virtual void login(User& user) = 0;
    virtual void logout(User& user) = 0;
    virtual ~AuthenticationSystem() {}
};

class NewAuthSystem : public AuthenticationSystem {
public:
    void registerUser(const string& name, const string& email) {
        cout << name << " is registered using the new system." << endl;
    }
    void loginUser(const string& name) {
        cout << name << " logged in using the new system." << endl;
    }
    void logoutUser(const string& name) {
        cout << name << " logged out using the new system." << endl;
    }

    void signup(User& user) override {
        registerUser(user.name, user.email);
    }
    void login(User& user) override {
        loginUser(user.name);
    }
    void logout(User& user) override {
        logoutUser(user.name);
    }
};

class UserAuthentication {
protected:
    AuthenticationSystem* authSystem;
public:
    UserAuthentication(AuthenticationSystem* system) : authSystem(system) {}

    void signup(User& user) {
        authSystem->signup(user);
    }
    void login(User& user) {
        authSystem->login(user);
    }
    void logout(User& user) {
        authSystem->logout(user);
    }
};

// ========== Job, CV, and User Roles ==========
class CV {
public:
    string filePath;
};

class CVManager {
public:
    void upload(CV& cv, const string& userName) {
        cout << "CV uploaded by " << userName << endl;
    }
    void review(CV&) {
        cout << "CV is under review." << endl;
    }
};

class Job {
private:
    int jobID;
    string title;
public:
    Job(int id, string t) : jobID(id), title(t) {}
    string getTitle() { return title; }
    int getJobID() { return jobID; }
};

class JobSeeker : public User {
private:
    CVManager cvManager;
public:
    void uploadCV(CV& cv) {
        cvManager.upload(cv, name);
    }
    void reviewCV(CV& cv) {
        cvManager.review(cv);
    }
    void findJob() {
        cout << name << " is looking for a job." << endl;
    }
    void applyForJob(Job& job) {
        cout << name << " applied for job: " << job.getTitle() << endl;
    }
};

class Admin : public User {
public:
    void manageUsers() {
        cout << "Admin : " << name << " managing users." << endl;
    }
    void manageJobs() {
        cout << "Admin : " << name << " managing jobs." << endl;
    }
    void generateReports() {
        cout << "Admin : " << name << " generating reports." << endl;
    }
};

class Employer : public User {
public:
    void postJob(Job& job) {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }
    void editJob(Job& job) {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }
    void deleteJob(Job& job) {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }
    void hireFreelancer(User& freelancer) {
        cout << "Employer hired freelancer: " << freelancer.name << endl;
    }
};

class Freelancer : public User {
public:
    void applyForFreelanceJob(Job& job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }
    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

// ========== MAIN ==========
int main() {
    cout << "\n=== Job Seeker Operations ===" << endl;
    JobSeeker js;
    js.name = "Awais Shabbir";
    js.email = "awais@example.com";

    NewAuthSystem bridgeSystem;
    UserAuthentication auth(&bridgeSystem);

    auth.signup(js);
    auth.login(js);

    CV cv;
    js.uploadCV(cv);
    js.findJob();
    Job job(1, "Software Engineer");
    js.applyForJob(job);
    auth.logout(js);

    cout << "\n=== Admin Operations ===" << endl;
    Admin admin;
    admin.name = "Owais Awan";
    auth.signup(admin);
    auth.login(admin);
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    auth.logout(admin);

    cout << "\n=== Employer Operations ===" << endl;
    Employer employer;
    employer.name = "Company Inc.";
    auth.signup(employer);
    auth.login(employer);
    Job job2(2, "Software Developer");
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    auth.logout(employer);

    cout << "\n=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.name = "Freelance Expert";
    auth.signup(freelancer);
    auth.login(freelancer);
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    auth.logout(freelancer);

    return 0;
}

// before

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name, email;
// };

// class NewAuthSystem {
// public:
//     void registerUser(const string& name, const string& email) {
//         cout << name << " registered using new system.\n";
//     }
//     void loginUser(const string& name) {
//         cout << name << " logged in using new system.\n";
//     }
// };

// int main() {
//     User user = {"Awais", "awais@example.com"};
//     NewAuthSystem auth;

//     auth.registerUser(user.name, user.email);
//     auth.loginUser(user.name);
// }

// After

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name, email;
// };

// // Bridge Interface
// class AuthenticationSystem {
// public:
//     virtual void signup(User& user) = 0;
//     virtual void login(User& user) = 0;
//     virtual ~AuthenticationSystem() {}
// };

// // Concrete Implementation
// class NewAuthSystem : public AuthenticationSystem {
// public:
//     void signup(User& user) override {
//         cout << user.name << " registered using new system.\n";
//     }
//     void login(User& user) override {
//         cout << user.name << " logged in using new system.\n";
//     }
// };

// // Abstraction (Bridge)
// class UserAuthentication {
//     AuthenticationSystem* system;
// public:
//     UserAuthentication(AuthenticationSystem* sys) : system(sys) {}
//     void signup(User& user) { system->signup(user); }
//     void login(User& user) { system->login(user); }
// };

// int main() {
//     User user = {"Awais", "awais@example.com"};
//     NewAuthSystem newSystem;
//     UserAuthentication auth(&newSystem);

//     auth.signup(user);
//     auth.login(user);
// }
