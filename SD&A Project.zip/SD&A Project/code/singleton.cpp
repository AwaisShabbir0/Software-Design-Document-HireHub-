#include <iostream>
#include <string>
using namespace std;

// ==================== User Base ====================
class User {
public:
    int userId;
    string name;
    string email;
    string password;
};

// ==================== Job and CV Classes ====================
class Job {
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;
public:
    Job(int id, string t, string d, string r, float s, int c)
        : jobID(id), title(t), description(d), requirements(r), salary(s), categoryID(c) {}

    string getTitle() { return title; }
    int getJobID() { return jobID; }
};

class CV {
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;
public:
    CV(int id, int uid, string path, string status)
        : cvID(id), userID(uid), filePath(path), reviewStatus(status) {}

    string getFilePath() { return filePath; }
};

// ==================== Singleton CVManager ====================
class CVManager {
private:
    static CVManager* instance;
    CVManager() {}

public:
    static CVManager* getInstance() {
        if (instance == nullptr) {
            instance = new CVManager();
        }
        return instance;
    }

    void upload(CV& cv, const string& name) {
        cout << "CV uploaded by " << name << endl;
    }

    void review(CV& cv, const string& name) {
        cout << name << " is reviewing their CV." << endl;
    }
};

CVManager* CVManager::instance = nullptr;

// ==================== Auth ====================
class UserAuthentication {
public:
    void login(User& user) {
        cout << user.name << " logged in." << endl;
    }
    void logout(User& user) {
        cout << user.name << " logged out." << endl;
    }
    void signup(User& user) {
        cout << user.name << " signed up." << endl;
    }
};

// ==================== Roles ====================
class JobSeeker : public User {
public:
    void applyForJob(Job& job) {
        cout << name << " applied for job: " << job.getTitle() << endl;
    }
    void uploadCV(CV& cv) {
        CVManager::getInstance()->upload(cv, name);
    }
    void reviewCV(CV& cv) {
        CVManager::getInstance()->review(cv, name);
    }
    void findJob() {
        cout << name << " is looking for a job." << endl;
    }
};

class Admin : public User {
public:
    void manageUsers() {
        cout << "Admin : " << name << " managing users." << endl;
    }
    void manageJobs() {
        cout << "Admin : " << name << " managing jobs." << endl;
    }
    void generateReports() {
        cout << "Admin : " << name << " generating reports." << endl;
    }
};

class Freelancer;

class Employer : public User {
public:
    void postJob(Job& job) {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }
    void editJob(Job& job) {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }
    void deleteJob(Job& job) {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }
    void hireFreelancer(Freelancer& freelancer);
};

class Freelancer : public User {
public:
    void applyForFreelanceJob(Job& job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }
    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

void Employer::hireFreelancer(Freelancer& freelancer) {
    cout << "Employer hired freelancer: " << freelancer.name << endl;
}

// ==================== Main ====================
int main() {
    UserAuthentication auth;

    cout << "\n=== Job Seeker Operations ===" << endl;
    JobSeeker js;
    js.name = "Awais Shabbir";
    js.userId = 1;
    auth.signup(js);
    auth.login(js);
    CV cv(1, js.userId, "cv_path.pdf", "Pending");
    js.uploadCV(cv);
    js.findJob();
    Job job1(1, "Software Engineer", "Develop software", "C++, Git", 75000, 101);
    js.applyForJob(job1);
    // js.reviewCV(cv);
    auth.logout(js);

    cout << "\n=== Admin Operations ===" << endl;
    Admin admin;
    admin.name = "Owais Awan";
    auth.signup(admin);
    auth.login(admin);
    admin.manageJobs();
    admin.manageUsers();
    admin.generateReports();
    auth.logout(admin);

    cout << "\n=== Employer Operations ===" << endl;
    Employer employer;
    employer.name = "Company Inc.";
    auth.signup(employer);
    auth.login(employer);
    Job job2(2, "Software Developer", "Develop apps", "Java, Spring", 80000, 102);
    employer.postJob(job2);
    employer.editJob(job2);
    employer.deleteJob(job2);
    auth.logout(employer);

    cout << "\n=== Freelancer Operations ===" << endl;
    Freelancer freelancer;
    freelancer.name = "Freelance Expert";
    auth.signup(freelancer);
    auth.login(freelancer);
    freelancer.applyForFreelanceJob(job2);
    freelancer.getHired();
    employer.hireFreelancer(freelancer);
    auth.logout(freelancer);

    return 0;
}

// ==================== Before Code ====================
// #include <iostream>
// #include <string>
// using namespace std;

// class CV {
// public:
//     string filePath;
//     CV(string path) : filePath(path) {}
// };

// class CVManager {
// public:
//     void upload(CV& cv, const string& name) {
//         cout << name << " uploaded CV: " << cv.filePath << endl;
//     }
// };

// int main() {
//     CV cv("cv_path.pdf");

//     CVManager manager1;
//     CVManager manager2;  // ❌ Multiple instances

//     manager1.upload(cv, "Awais");
//     manager2.upload(cv, "Owais");

//     return 0;
// }



// ==================== After Code ====================
//     #include <iostream>
// #include <string>
// using namespace std;

// class CV {
// public:
//     string filePath;
//     CV(string path) : filePath(path) {}
// };

// class CVManager {
// private:
//     static CVManager* instance;
//     CVManager() {}  // ✅ Private constructor

// public:
//     static CVManager* getInstance() {
//         if (!instance)
//             instance = new CVManager();
//         return instance;
//     }

//     void upload(CV& cv, const string& name) {
//         cout << name << " uploaded CV: " << cv.filePath << endl;
//     }
// };

// CVManager* CVManager::instance = nullptr;

// int main() {
//     CV cv("cv_path.pdf");

//     // ✅ Only one shared instance used
//     CVManager::getInstance()->upload(cv, "Awais");
//     CVManager::getInstance()->upload(cv, "Owais");

//     return 0;
// }
