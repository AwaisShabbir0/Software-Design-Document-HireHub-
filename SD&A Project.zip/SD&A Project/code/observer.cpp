// ========== BEFORE Applying Observer Pattern ==========
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

class JobApplicationBefore {
private:
    string status;
public:
    void updateStatus(const string& newStatus) {
        status = newStatus;
        cout << "Application status updated to: " << status << endl;
        // No notifications sent
    }
};

// ========== AFTER Applying Observer Pattern ==========
#include <vector>

class JobApplication; // Forward declaration

// Observer Interface
class JobApplicationObserver {
public:
    virtual void update(JobApplication* app) = 0;
};

// Subject Interface
class JobApplicationSubject {
public:
    virtual void addObserver(JobApplicationObserver* observer) = 0;
    virtual void removeObserver(JobApplicationObserver* observer) = 0;
    virtual void notifyObservers() = 0;
};

// Concrete JobApplication class
class JobApplication : public JobApplicationSubject {
private:
    int jobID;
    int userID;
    string status;
    vector<JobApplicationObserver*> observers;

public:
    JobApplication(int uid, int jid) : userID(uid), jobID(jid), status("Applied") {}

    void updateStatus(const string& newStatus) {
        status = newStatus;
        cout << "Application status updated to: " << status << endl;
        notifyObservers();
    }

    string getStatus() const {
        return status;
    }

    void addObserver(JobApplicationObserver* observer) override {
        observers.push_back(observer);
    }

    void removeObserver(JobApplicationObserver* observer) override {
        observers.erase(remove(observers.begin(), observers.end(), observer), observers.end());
    }

    void notifyObservers() override {
        for (auto& obs : observers) {
            obs->update(this);
        }
    }
};

// Concrete Observer: Job Seeker
class JobSeekerObserver : public JobApplicationObserver {
public:
    void update(JobApplication* app) override {
        cout << "Job Seeker notified: Application status updated to " << app->getStatus() << endl;
    }
};

// Concrete Observer: Admin
class AdminObserver : public JobApplicationObserver {
public:
    void update(JobApplication* app) override {
        cout << "Admin notified: Application status updated to " << app->getStatus() << endl;
    }
};

// ========== Main Simulation ==========
int main() {
    cout << "\n=== Observer Pattern Demo ===" << endl;

    JobApplication app(1, 101);
    JobSeekerObserver jobSeeker;
    AdminObserver admin;

    app.addObserver(&jobSeeker);
    app.addObserver(&admin);

    app.updateStatus("Under Review");
    app.updateStatus("Shortlisted");
    app.updateStatus("Rejected");

    return 0;
}

// before

// #include <iostream>
// #include <string>
// using namespace std;

// class JobApplicationBefore {
//     string status;
// public:
//     void updateStatus(const string& newStatus) {
//         status = newStatus;
//         cout << "Application status updated to: " << status << endl;
//         // No notification system ❌
//     }
// };

// int main() {
//     JobApplicationBefore app;
//     app.updateStatus("Under Review");
//     return 0;
// }

//after

// #include <iostream>
// #include <vector>
// #include <algorithm>
// using namespace std;

// // Forward declaration
// class JobApplication;

// // Observer Interface
// class Observer {
// public:
//     virtual void update(JobApplication* app) = 0;
// };

// // Subject Class (Observable)
// class JobApplication {
//     string status;
//     vector<Observer*> observers;
// public:
//     void addObserver(Observer* obs) {
//         observers.push_back(obs);
//     }

//     void removeObserver(Observer* obs) {
//         observers.erase(remove(observers.begin(), observers.end(), obs), observers.end());
//     }

//     void notify() {
//         for (auto obs : observers) obs->update(this);
//     }

//     void updateStatus(const string& newStatus) {
//         status = newStatus;
//         cout << "Status changed to: " << status << endl;
//         notify();
//     }

//     string getStatus() const {
//         return status;
//     }
// };

// // Concrete Observer - JobSeeker
// class JobSeeker : public Observer {
// public:
//     void update(JobApplication* app) override {
//         cout << "JobSeeker notified: " << app->getStatus() << endl;
//     }
// };

// // Concrete Observer - Admin
// class Admin : public Observer {
// public:
//     void update(JobApplication* app) override {
//         cout << "Admin notified: " << app->getStatus() << endl;
//     }
// };

// // Main Simulation
// int main() {
//     JobApplication app;
//     JobSeeker seeker;
//     Admin admin;

//     app.addObserver(&seeker);
//     app.addObserver(&admin);

//     app.updateStatus("Under Review");
//     app.updateStatus("Shortlisted");
//     app.updateStatus("Rejected");

//     return 0;
// }

