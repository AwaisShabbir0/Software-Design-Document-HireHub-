#include <iostream>
#include <string>
#include <memory>
using namespace std;

// ================= USER BASE =================
class User {
public:
    int userId;
    string name;
    string email;
    string password;
    virtual ~User() {}
};

// ================= JOB & CV =================
class Job {
private:
    int jobID;
    string title;
    string description;
    string requirements;
    float salary;
    int categoryID;

public:
    Job(int jobID, string title, string description, string requirements, float salary, int categoryID)
        : jobID(jobID), title(title), description(description), requirements(requirements),
          salary(salary), categoryID(categoryID) {}

    int getJobID() { return jobID; }
    string getTitle() { return title; }
};

class CV {
private:
    int cvID;
    int userID;
    string filePath;
    string reviewStatus;

public:
    CV() {}
    CV(int cvID, int userID, string filePath, string reviewStatus)
        : cvID(cvID), userID(userID), filePath(filePath), reviewStatus(reviewStatus) {}

    string getFilePath() { return filePath; }
    void setFilePath(const string& path) { filePath = path; }
};

class CVManager {
public:
    void upload(CV& cv, string name) {
        cout << "CV uploaded by " << name << endl;
    }

    void review(CV& cv, string name) {
        cout << name << " is reviewing their CV." << endl;
    }
};

// ================= ROLES =================
class JobSeeker : public User {
private:
    CVManager cvManager;

public:
    void applyForJob(Job& job) {
        cout << name << " applied for job: " << job.getTitle() << endl;
    }
    void findJob() {
        cout << name << " is looking for a job." << endl;
    }
    void uploadCV(CV& cv) {
        cvManager.upload(cv, name);
    }
    void reviewCV(CV& cv) {
        cvManager.review(cv, name);
    }
};

class Admin : public User {
public:
    void manageUsers() {
        cout << "Admin : " << name << " managing users." << endl;
    }
    void manageJobs() {
        cout << "Admin : " << name << " managing jobs." << endl;
    }
    void generateReports() {
        cout << "Admin : " << name << " generating reports." << endl;
    }
};

class Freelancer; // Forward declaration

class Employer : public User {
public:
    void postJob(Job& job) {
        cout << "Employer posted job: " << job.getTitle() << endl;
    }
    void editJob(Job& job) {
        cout << "Employer edited job: " << job.getTitle() << endl;
    }
    void deleteJob(Job& job) {
        cout << "Employer deleted job: " << job.getTitle() << endl;
    }
    void hireFreelancer(Freelancer& freelancer);
};

class Freelancer : public User {
public:
    void applyForFreelanceJob(Job& job) {
        cout << name << " applied for freelance job: " << job.getTitle() << endl;
    }
    void getHired() {
        cout << name << " got hired for a freelance job." << endl;
    }
};

void Employer::hireFreelancer(Freelancer& freelancer) {
    cout << "Employer hired freelancer: " << freelancer.name << endl;
}

// ================= AUTH =================
class UserAuthentication {
public:
    void login(User& user) {
        cout << user.name << " logged in." << endl;
    }
    void logout(User& user) {
        cout << user.name << " logged out." << endl;
    }
    void signup(User& user) {
        cout << user.name << " signed up." << endl;
    }
};

// ================= FACTORY =================
enum UserType { JOB_SEEKER, EMPLOYER, ADMIN, FREELANCER };

class UserFactory {
public:
    static User* createUser(UserType type) {
        switch (type) {
            case JOB_SEEKER: return new JobSeeker();
            case EMPLOYER: return new Employer();
            case ADMIN: return new Admin();
            case FREELANCER: return new Freelancer();
            default: return nullptr;
        }
    }
};

// ================= MAIN =================
int main() {
    UserAuthentication auth;

    cout << "\n=== Job Seeker Operations ===" << endl;
    User* seekerUser = UserFactory::createUser(JOB_SEEKER);
    seekerUser->name = "Awais Shabbir";
    seekerUser->userId = 101;
    auth.signup(*seekerUser);
    auth.login(*seekerUser);
    JobSeeker* jobSeeker = dynamic_cast<JobSeeker*>(seekerUser);
    CV cv(1, seekerUser->userId, "cv_path.pdf", "Pending");
    jobSeeker->uploadCV(cv);
    jobSeeker->findJob();
    Job job1(1, "Software Engineer", "Build systems", "C++, Git", 80000, 10);
    jobSeeker->applyForJob(job1);
    auth.logout(*seekerUser);

    cout << "\n=== Admin Operations ===" << endl;
    User* adminUser = UserFactory::createUser(ADMIN);
    adminUser->name = "Owais Awan";
    auth.signup(*adminUser);
    auth.login(*adminUser);
    Admin* admin = dynamic_cast<Admin*>(adminUser);
    admin->manageJobs();
    admin->manageUsers();
    admin->generateReports();
    auth.logout(*adminUser);

    cout << "\n=== Employer Operations ===" << endl;
    User* employerUser = UserFactory::createUser(EMPLOYER);
    employerUser->name = "Company Inc.";
    auth.signup(*employerUser);
    auth.login(*employerUser);
    Employer* employer = dynamic_cast<Employer*>(employerUser);
    Job job2(2, "Software Developer", "Develop applications", "Java, Spring", 60000, 101);
    employer->postJob(job2);
    employer->editJob(job2);
    employer->deleteJob(job2);
    auth.logout(*employerUser);

    cout << "\n=== Freelancer Operations ===" << endl;
    User* freelancerUser = UserFactory::createUser(FREELANCER);
    freelancerUser->name = "Freelance Expert";
    auth.signup(*freelancerUser);
    auth.login(*freelancerUser);
    Freelancer* freelancer = dynamic_cast<Freelancer*>(freelancerUser);
    freelancer->applyForFreelanceJob(job2);
    freelancer->getHired();
    employer->hireFreelancer(*freelancer);
    auth.logout(*freelancerUser);

    delete seekerUser;
    delete adminUser;
    delete employerUser;
    delete freelancerUser;

    return 0;
}
// before 

// #include <iostream>
// #include <string>
// using namespace std;

// class User {
// public:
//     string name;
//     virtual void roleAction() = 0;
// };

// class JobSeeker : public User {
// public:
//     void roleAction() override {
//         cout << name << " is searching for a job." << endl;
//     }
// };

// class Employer : public User {
// public:
//     void roleAction() override {
//         cout << name << " is posting a job." << endl;
//     }
// };

// int main() {
//     // Manually creating objects using 'new'
//     User* user1 = new JobSeeker();
//     user1->name = "Awais";
//     user1->roleAction();

//     User* user2 = new Employer();
//     user2->name = "Owais";
//     user2->roleAction();

//     delete user1;
//     delete user2;
//     return 0;
// }

//AFter

// #include <iostream>
// #include <string>
// using namespace std;

// // ===== Abstract Base Class =====
// class User {
// public:
//     string name;
//     virtual void roleAction() = 0;
//     virtual ~User() {}
// };

// // ===== Derived Classes =====
// class JobSeeker : public User {
// public:
//     void roleAction() override {
//         cout << name << " is searching for a job." << endl;
//     }
// };

// class Employer : public User {
// public:
//     void roleAction() override {
//         cout << name << " is posting a job." << endl;
//     }
// };

// // ===== Enum & Factory =====
// enum UserType { JOB_SEEKER, EMPLOYER };

// class UserFactory {
// public:
//     static User* createUser(UserType type) {
//         switch (type) {
//             case JOB_SEEKER: return new JobSeeker();
//             case EMPLOYER: return new Employer();
//             default: return nullptr;
//         }
//     }
// };

// // ===== Main Function =====
// int main() {
//     User* user1 = UserFactory::createUser(JOB_SEEKER);
//     user1->name = "Awais";
//     user1->roleAction();

//     User* user2 = UserFactory::createUser(EMPLOYER);
//     user2->name = "Owais";
//     user2->roleAction();

//     delete user1;
//     delete user2;

//     return 0;
// }
