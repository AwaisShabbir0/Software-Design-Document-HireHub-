// before

// class CV {
//     private String filePath;
//     public CV(String filePath) {
//         this.filePath = filePath;
//     }
//     public String getFilePath() {
//         return filePath;
//     }
// }

// class CVManager {
//     public void upload(CV cv) {
//         System.out.println("CV uploaded at: " + cv.getFilePath());
//     }
//     public void review(CV cv) {
//         System.out.println("CV is under review.");
//     }
// }

// class JobPostingService {
//     public void postJob(Job job) {
//         System.out.println("Job posted: " + job.getTitle());
//     }
//     public void editJob(Job job) {
//         System.out.println("Job edited: " + job.getTitle());
//     }
//     public void deleteJob(Job job) {
//         System.out.println("Job deleted: " + job.getTitle());
//     }
// }

// class Job {
//     private int jobID;
//     private String title;
//     public Job(int jobID, String title) {
//         this.jobID = jobID;
//         this.title = title;
//     }
//     public String getTitle() {
//         return title;
//     }
// }

// class JobSeeker {
//     private CVManager cvManager = new CVManager();  // Tightly coupled

//     public void uploadCV(CV cv) {
//         cvManager.upload(cv);
//     }

//     public void reviewCV(CV cv) {
//         cvManager.review(cv);
//     }
// }

// class Admin {
//     private JobPostingService jobService = new JobPostingService();  // Tightly coupled

//     public void postJob(Job job) {
//         jobService.postJob(job);
//     }
// }

//After

// Abstractions
// interface ICVManager {
//     void upload(CV cv);
//     void review(CV cv);
// }

// interface IJobPostingService {
//     void postJob(Job job);
//     void editJob(Job job);
//     void deleteJob(Job job);
// }

// // Implementations
// class CVManager implements ICVManager {
//     public void upload(CV cv) {
//         System.out.println("CV uploaded at: " + cv.getFilePath());
//     }
//     public void review(CV cv) {
//         System.out.println("CV is under review.");
//     }
// }

// class JobPostingService implements IJobPostingService {
//     public void postJob(Job job) {
//         System.out.println("Job posted: " + job.getTitle());
//     }
//     public void editJob(Job job) {
//         System.out.println("Job edited: " + job.getTitle());
//     }
//     public void deleteJob(Job job) {
//         System.out.println("Job deleted: " + job.getTitle());
//     }
// }

// // Models
// class Job {
//     private int jobID;
//     private String title;
//     public Job(int jobID, String title) {
//         this.jobID = jobID;
//         this.title = title;
//     }
//     public String getTitle() {
//         return title;
//     }
// }

// // High-level modules
// class JobSeeker {
//     private ICVManager cvManager;
//     public JobSeeker(ICVManager cvManager) {
//         this.cvManager = cvManager;
//     }
//     public void uploadCV(CV cv) {
//         cvManager.upload(cv);
//     }
//     public void reviewCV(CV cv) {
//         cvManager.review(cv);
//     }
// }

// class Admin {
//     private IJobPostingService jobService;
//     public Admin(IJobPostingService jobService) {
//         this.jobService = jobService;
//     }
//     public void postJob(Job job) {
//         jobService.postJob(job);
//     }
// }

