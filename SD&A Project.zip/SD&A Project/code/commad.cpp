#include <iostream>
#include <string>
using namespace std;

// ===== User Class =====
class User {
public:
    string name;
    string email;
    string password;
};

// ===== Authentication System =====
class AuthenticationSystem {
public:
    void registerUser(const string& name, const string& email) {
        cout << name << " is registered using the new system." << endl;
    }
    void loginUser(const string& name) {
        cout << name << " logged in using the new system." << endl;
    }
    void logoutUser(const string& name) {
        cout << name << " logged out using the new system." << endl;
    }
};

// ===== Command Interface =====
class UserCommand {
public:
    virtual void execute(User& user) = 0;
    virtual ~UserCommand() {}
};

// ===== Concrete Commands =====
class SignupCommand : public UserCommand {
    AuthenticationSystem* auth;
public:
    SignupCommand(AuthenticationSystem* authSystem) : auth(authSystem) {}
    void execute(User& user) override {
        auth->registerUser(user.name, user.email);
    }
};

class LoginCommand : public UserCommand {
    AuthenticationSystem* auth;
public:
    LoginCommand(AuthenticationSystem* authSystem) : auth(authSystem) {}
    void execute(User& user) override {
        auth->loginUser(user.name);
    }
};

class LogoutCommand : public UserCommand {
    AuthenticationSystem* auth;
public:
    LogoutCommand(AuthenticationSystem* authSystem) : auth(authSystem) {}
    void execute(User& user) override {
        auth->logoutUser(user.name);
    }
};

// ===== Invoker =====
class UserCommandInvoker {
    UserCommand* command;
public:
    void setCommand(UserCommand* cmd) {
        command = cmd;
    }
    void invoke(User& user) {
        if (command)
            command->execute(user);
    }
};

// ===== Main =====
int main() {
    cout << "\n=== Command Pattern: User Authentication ===" << endl;

    User user;
    user.name = "Awais Shabbir";
    user.email = "awais@example.com";

    AuthenticationSystem authSystem;

    SignupCommand signup(&authSystem);
    LoginCommand login(&authSystem);
    LogoutCommand logout(&authSystem);

    UserCommandInvoker invoker;

    invoker.setCommand(&signup);
    invoker.invoke(user);

    invoker.setCommand(&login);
    invoker.invoke(user);

    invoker.setCommand(&logout);
    invoker.invoke(user);

    return 0;
}

// before

// #include <iostream>
// using namespace std;

// class User {
// public:
//     string name = "Awais";
//     string email = "awais@example.com";
// };

// class AuthSystem {
// public:
//     void registerUser(string name, string email) {
//         cout << name << " registered.\n";
//     }
//     void loginUser(string name) {
//         cout << name << " logged in.\n";
//     }
// };

// int main() {
//     User user;
//     AuthSystem auth;

//     auth.registerUser(user.name, user.email);  // Direct call
//     auth.loginUser(user.name);                 // Direct call
// }

// after

// #include <iostream>
// using namespace std;

// // Receiver
// class AuthSystem {
// public:
//     void registerUser(string name, string email) {
//         cout << name << " registered.\n";
//     }
//     void loginUser(string name) {
//         cout << name << " logged in.\n";
//     }
// };

// // Command Interface
// class Command {
// public:
//     virtual void execute() = 0;
// };

// // Concrete Commands
// class SignupCommand : public Command {
//     AuthSystem* auth;
//     string name, email;
// public:
//     SignupCommand(AuthSystem* a, string n, string e) : auth(a), name(n), email(e) {}
//     void execute() override { auth->registerUser(name, email); }
// };

// class LoginCommand : public Command {
//     AuthSystem* auth;
//     string name;
// public:
//     LoginCommand(AuthSystem* a, string n) : auth(a), name(n) {}
//     void execute() override { auth->loginUser(name); }
// };

// // Invoker
// class Invoker {
// public:
//     void run(Command* cmd) { cmd->execute(); }
// };

// // Main
// int main() {
//     AuthSystem auth;
//     Invoker invoker;

//     SignupCommand signup(&auth, "Awais", "awais@example.com");
//     LoginCommand login(&auth, "Awais");

//     invoker.run(&signup);
//     invoker.run(&login);

//     return 0;
// }
